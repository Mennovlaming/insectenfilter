## Insectenfilter

Welkom bij de readme van het insectenfilter. 

### introductie
Wij (Menno, Reniet, Quinty) hebben van school een opdracht gekregen om project te maken voor Naturalis, die opzoek waren naar een dashboard/ overzichtelijke weergave van hun camera's die insecten waarnemen. Als oplossing hebben we een prototype gemaakt waarmee we dus eigenlijk een ontwerprichting in gaan voor Naturalis. Om de technische haalbaarheid van dit prototype te onderzoeken, hebben wij een deel van dit prototype gerealiseerd voor op het web. Neem een kijkje in de wiki om wekelijkse voortgang te zien en om te kijken hoe we te werk zijn gegaan.

### Setup project
Om het project te kunnen runnen, moet je NPM geinstalleerd hebben.
Om NPM te installeren, type in de terminal:

'NPM install'

Er zitten in de package.json een aantal voorgeprogrammerde commando's om de app te runnen, eentje hiervan is 'start'. Om te app te runnen, navigeer naar de juiste folder en type in de terminal:

'NPM start'

